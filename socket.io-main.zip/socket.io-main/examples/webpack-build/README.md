
# Socket.IO WebPack build

A sample Webpack build for the browser.

## How to use

```
$ npm i
$ npm run build
```
