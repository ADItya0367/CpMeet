export const environment = {
  serverUrl: "http://localhost:3000"
};
