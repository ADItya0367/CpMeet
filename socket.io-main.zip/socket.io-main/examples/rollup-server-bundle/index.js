import { Server } from "socket.io";

new Server(0);
