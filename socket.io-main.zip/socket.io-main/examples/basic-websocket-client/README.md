# Basic Socket.IO client

Please check the associated guide: https://socket.io/how-to/build-a-basic-client

Content:

```
├── bundle
│   └── socket.io.min.js
├── src
│   └── index.js
├── test
│   └── index.js
├── check-bundle-size.js
├── package.json
├── README.md
└── rollup.config.js
```
